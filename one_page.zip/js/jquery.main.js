jQuery(function() {
    $(document).ready(function(){

        $(".btn-search").click(function(){
            $(".wrap, .input").toggleClass("active");
            $("input[type='text']").focus();
        });

    });
});


jQuery(function() {
    $(document).ready(function (){
        $('.button-container').click(function (event){
            $('.button-container,#main_nav').toggleClass('active')
        });
    });
});