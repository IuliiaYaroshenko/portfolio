$(document).ready(function() {  
	$(".tabs .nav a").click(function() {
		var container = $(this).parentsUntil(".tabs").parent();
		if (!$(this).parent().hasClass("current")) {
			container.find(".nav .current").removeClass("current")
			$(this).parent().addClass("current")
			container.find(".tab-content").hide()
			$($(this).attr("href")).show();
		};
		return false;
	});
    $('.signup-page input[type=radio]').crfi();
    $('.bxslider').bxSlider({
        pagerCustom: $('.sub-nav')
    });
	$(".btn-search span").click(function() {
        if($(".box-search").css('display') == 'none') {
        	$(".box-search").addClass("active");
        	$(".search-hidden").addClass("active");
            $(".box-search").fadeIn('slow');
        }
        else {
            $(".box-search").fadeOut('hide');
            $(".box-search").removeClass("active");
            $(".search-hidden").removeClass("active");
        }
        return false;
    });
	jQuery(document).on('click', "#menu_trigger", function (e) {
		e.preventDefault()
		window.setTimeout(function() {
			if(jQuery('.nav-bar').hasClass('clicked')){
				jQuery('.nav-bar').stop(true,true).animate({height:'hide'},100);
				jQuery('.nav-bar').removeClass('clicked');
			}else{
				jQuery('.nav-bar').stop(true,true).animate({height:'show'},400);
				jQuery('.nav-bar').addClass('clicked');
			}
		}, 400);
		return false;
	});
	jQuery("nav").on('click', '.drops', function () {
		if (jQuery(this).hasClass("active")) {
			jQuery(this).removeClass("active").parent().next().slideUp();
		} else {
			jQuery(this).addClass("active").parent().next().slideDown();
		}
		return false;
	});
});  
$(document).click(function(event) {
    if($(event.target).hasClass('active')) return;
    if($(event.target).parents().hasClass('active')) return;
    $('.box-search').fadeOut('hide');
    $('.search-hidden').removeClass("active");
});
$(window).resize(function() {
	if($(document).width() > 981){
	  $( ".nav-bar" ).addClass("active");
	  $( "#nav ul" ).attr('style','');
	  $( ".nav-bar" ).attr('style','');
	  $( ".nav-bar" ).removeClass("clicked");
	  $( ".nav-bar .active" ).removeClass('active');
	}
	else {
		$( "#nav" ).removeClass("active");
	}
 });