$(document).ready(function() {
	
	$('input[placeholder], textarea[placeholder]').placeholder();
	$( "#tabs" ).tabs();
      jQuery(document).on('click', ".menu_trigger", function (e) {
        e.preventDefault()
        window.setTimeout(function() {
            if(jQuery('#nav').hasClass('clicked')){
                jQuery('#nav').stop(true,true).animate({height:'hide'},100);
                jQuery('#nav').removeClass('clicked');
            }else{
                jQuery('#nav').stop(true,true).animate({height:'show'},400);
                jQuery('#nav').addClass('clicked');
            }
        }, 400);
        return false;
    });
    jQuery("#nav").on('click', '.drops', function () {
        if (jQuery(this).hasClass("active")) {
            jQuery(this).removeClass("active").parent().next().slideUp();
        } else {
            jQuery(this).addClass("active").parent().next().slideDown();
        }
        return false;
    });
      
}); 

$(window).resize(function() {
    if($(document).width() > 768){
      $( "#nav" ).addClass("active");
      $( "#nav ul" ).attr('style','');
      $( "#nav" ).attr('style','');
      $( "#nav" ).removeClass("clicked");
      $( "#nav .active" ).removeClass('active');
    }
    else {
        $( "#nav" ).removeClass("active");
    }
});
$(document).ready(function(){
	$('ul.accordion').accordion({
		active: ".selected",
		autoHeight: false,
		header: ".opener",
		collapsible: true,
		event: "click"
	});
});
$(function() {


		$("#accordion ").each( function() {
     if ($(this).find('ul').length != 0) 
     {
        $(this).accordion({collapsible: true,
        heightStyle: ""})
     }
    });
	$("input[type=radio],input[type=file]").uniform();
     });
     


 

$(".view_module").click(function() {
        if($(".view_module_holder").css('display') == 'none') {
         $('.view_module').addClass('selected');
            $('.view_module_holder').stop(true,true).animate({fadeIn:'show'}, 800);
        }
        else {
             $('.view_module_holder').stop(true,true).animate({fadeOut:'hide'}, 500);
             $('.view_module').removeClass('selected');
        }
        return false;
    });
    $(document).click(function(event) {
     if($(event.target).parents().hasClass('view_module_holder')) return;
  $('.view_module_holder').fadeOut('hide');
 });
	
