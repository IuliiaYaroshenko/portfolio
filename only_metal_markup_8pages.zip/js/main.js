// page init
jQuery(function(){
    initMobileMenu();
    initMobileNavOpener();
});
// mobile-menu  init
function initMobileMenu() {
    $('.button-container').on('click', function() {
        $(this).toggleClass('active');
        if( $(this).hasClass('active') ) {
            $('body').addClass('active-menu');
        } else {
            $('body').removeClass('active-menu');
        }
    });

    $(window).resize(function() {
        if($(window).width() >= 1023) {
            $('body').removeClass('active-menu');
            $('.button-container').removeClass('active');
            $('.nav li').removeClass('actives');
            $('.drop-nav').stop().slideUp();
        }
    }).resize();
}