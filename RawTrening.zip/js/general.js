(function($) {
	$(document).ready(function() {
		$(".tabs .nav a").click(function() {
		var container = $(this).parentsUntil(".tabs").parent();
		if (!$(this).parent().hasClass("current")) {
			container.find(".nav .current").removeClass("current")
			$(this).parent().addClass("current")
			container.find(".tab-content").hide()
			$($(this).attr("href")).show();
		};
		return false;
	});
		$('input[placeholder], textarea[placeholder]').placeholder();
	    $("select").uniform();
		

		$( "#nav li" ).each(function(){
		     if($(this).find('ul').length){
		          $(this).find('>a').append('<span class="drops"></span>');
		     }
		});
	    jQuery(document).on('click', ".menu_trigger", function (e) {
	        e.preventDefault()
	        window.setTimeout(function() {
	            if(jQuery('#nav').hasClass('clicked')){
	                jQuery('#nav').stop(true,true).animate({height:'hide'},100);
	                jQuery('#nav').removeClass('clicked');
	            }else{
	                jQuery('#nav').stop(true,true).animate({height:'show'},400);
	                jQuery('#nav').addClass('clicked');
	            }
	        }, 400);
	        return false;
	    });
	    jQuery("#nav").on('click', '.drops', function () {
	        if (jQuery(this).hasClass("actives")) {
	            jQuery(this).removeClass("actives").parent().next().slideUp();
	        } else {
	            jQuery(this).addClass("actives").parent().next().slideDown();
	        }
	        return false;
	    });
	});
	$(window).resize(function() {
	    if($(document).width() > 768){
	      $( "#nav" ).addClass("active");
	      $( "#nav .sub-menu" ).attr('style','');
	      $( "#nav" ).attr('style','');
	      $( "#nav" ).removeClass("clicked");
	      $( "#nav .active" ).removeClass('active');
	    }
	    else {
	        $( "#nav" ).removeClass("active");
	    }
	});
	
	var pageNum, max, nextLink;
	var loading = false;
	
	

})(jQuery);