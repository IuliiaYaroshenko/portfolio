(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var _sliderClient = require('./modules/slider-client');

var _sliderClient2 = _interopRequireDefault(_sliderClient);

var _headerMenu = require('./modules/header-menu');

var _headerMenu2 = _interopRequireDefault(_headerMenu);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(function ($, $wnd, $body, $doc) {

    $(function () {
        _sliderClient2.default.init();
        _headerMenu2.default.init();
    });
})(jQuery, $(window), $('body'), $(document));

},{"./modules/header-menu":2,"./modules/slider-client":3}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var headerMenu = function ($) {
    'use strict';

    function init() {
        $(".cross").hide();
        $(".hamburger").click(function () {
            $(".header__nav").slideToggle("slow", function () {
                $(".hamburger").hide();
                $(".cross").show();
            });
        });

        $(".cross").click(function () {
            $(".header__nav").slideToggle("slow", function () {
                $(".cross").hide();
                $(".hamburger").show();
            });
        });
    }

    return {
        init: init
    };
}(jQuery);

exports.default = headerMenu;

},{}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
var clientSlider = function ($) {
    'use strict';

    var slickSlider = $('.slick-slider');

    function init() {
        slickSlider.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: false
        });
    }

    return {
        init: init
    };
}(jQuery);

exports.default = clientSlider;

},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvanMvYXBwLmpzIiwic3JjL2pzL21vZHVsZXMvaGVhZGVyLW1lbnUuanMiLCJzcmMvanMvbW9kdWxlcy9zbGlkZXItY2xpZW50LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7QUNBQTs7OztBQUNBOzs7Ozs7QUFFQyxXQUFVLENBQVYsRUFBYSxJQUFiLEVBQW1CLEtBQW5CLEVBQTBCLElBQTFCLEVBQWdDOztBQUU3QixNQUFFLFlBQVk7QUFDViwrQkFBYSxJQUFiO0FBQ0EsNkJBQVcsSUFBWDtBQUNILEtBSEQ7QUFLSCxDQVBBLEVBT0MsTUFQRCxFQU9TLEVBQUUsTUFBRixDQVBULEVBT29CLEVBQUUsTUFBRixDQVBwQixFQU8rQixFQUFFLFFBQUYsQ0FQL0IsQ0FBRDs7Ozs7Ozs7O0FDRkEsSUFBSSxhQUFjLFVBQVMsQ0FBVCxFQUFZO0FBQzFCOztBQUVBLGFBQVMsSUFBVCxHQUFnQjtBQUNaLFVBQUcsUUFBSCxFQUFjLElBQWQ7QUFDQSxVQUFHLFlBQUgsRUFBa0IsS0FBbEIsQ0FBd0IsWUFBVztBQUNuQyxjQUFHLGNBQUgsRUFBb0IsV0FBcEIsQ0FBaUMsTUFBakMsRUFBeUMsWUFBVztBQUNoRCxrQkFBRyxZQUFILEVBQWtCLElBQWxCO0FBQ0Esa0JBQUcsUUFBSCxFQUFjLElBQWQ7QUFDSCxhQUhEO0FBSUMsU0FMRDs7QUFPQSxVQUFHLFFBQUgsRUFBYyxLQUFkLENBQW9CLFlBQVc7QUFDM0IsY0FBRyxjQUFILEVBQW9CLFdBQXBCLENBQWlDLE1BQWpDLEVBQXlDLFlBQVc7QUFDaEQsa0JBQUcsUUFBSCxFQUFjLElBQWQ7QUFDQSxrQkFBRyxZQUFILEVBQWtCLElBQWxCO0FBQ0gsYUFIRDtBQUlILFNBTEQ7QUFNQzs7QUFFTCxXQUFPO0FBQ0gsY0FBTTtBQURILEtBQVA7QUFHSCxDQXZCaUIsQ0F1QmhCLE1BdkJnQixDQUFsQjs7a0JBeUJlLFU7Ozs7Ozs7O0FDMUJmLElBQUksZUFBZ0IsVUFBUyxDQUFULEVBQVk7QUFDNUI7O0FBRUEsUUFBSSxjQUFjLEVBQUUsZUFBRixDQUFsQjs7QUFFQSxhQUFTLElBQVQsR0FBZ0I7QUFDWixvQkFBWSxLQUFaLENBQWtCO0FBQ2QsMEJBQWMsQ0FEQTtBQUVkLDRCQUFnQixDQUZGO0FBR2Qsb0JBQVEsSUFITTtBQUlkLGtCQUFNO0FBSlEsU0FBbEI7QUFNSDs7QUFFRCxXQUFPO0FBQ0gsY0FBTTtBQURILEtBQVA7QUFHSCxDQWpCbUIsQ0FpQmxCLE1BakJrQixDQUFwQjs7a0JBbUJlLFkiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCJpbXBvcnQgY2xpZW50U2xpZGVyIGZyb20gJy4vbW9kdWxlcy9zbGlkZXItY2xpZW50JztcbmltcG9ydCBoZWFkZXJNZW51IGZyb20gJy4vbW9kdWxlcy9oZWFkZXItbWVudSc7XG5cbihmdW5jdGlvbiAoJCwgJHduZCwgJGJvZHksICRkb2MpIHtcblxuICAgICQoZnVuY3Rpb24gKCkge1xuICAgICAgICBjbGllbnRTbGlkZXIuaW5pdCgpO1xuICAgICAgICBoZWFkZXJNZW51LmluaXQoKTtcbiAgICB9KTtcblxufShqUXVlcnksICQod2luZG93KSwgJCgnYm9keScpLCAkKGRvY3VtZW50KSkpO1xuXG5cblxuIiwiXHJcbnZhciBoZWFkZXJNZW51ID0gKGZ1bmN0aW9uKCQpIHtcclxuICAgICd1c2Ugc3RyaWN0JztcclxuXHJcbiAgICBmdW5jdGlvbiBpbml0KCkge1xyXG4gICAgICAgICQoIFwiLmNyb3NzXCIgKS5oaWRlKCk7XHJcbiAgICAgICAgJCggXCIuaGFtYnVyZ2VyXCIgKS5jbGljayhmdW5jdGlvbigpIHtcclxuICAgICAgICAkKCBcIi5oZWFkZXJfX25hdlwiICkuc2xpZGVUb2dnbGUoIFwic2xvd1wiLCBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgJCggXCIuaGFtYnVyZ2VyXCIgKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICQoIFwiLmNyb3NzXCIgKS5zaG93KCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICQoIFwiLmNyb3NzXCIgKS5jbGljayhmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgJCggXCIuaGVhZGVyX19uYXZcIiApLnNsaWRlVG9nZ2xlKCBcInNsb3dcIiwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAkKCBcIi5jcm9zc1wiICkuaGlkZSgpO1xyXG4gICAgICAgICAgICAgICAgJCggXCIuaGFtYnVyZ2VyXCIgKS5zaG93KCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGluaXQ6IGluaXRcclxuICAgIH07XHJcbn0oalF1ZXJ5KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBoZWFkZXJNZW51OyIsInZhciBjbGllbnRTbGlkZXIgPSAoZnVuY3Rpb24oJCkge1xyXG4gICAgJ3VzZSBzdHJpY3QnO1xyXG5cclxuICAgIGxldCBzbGlja1NsaWRlciA9ICQoJy5zbGljay1zbGlkZXInKTtcclxuXHJcbiAgICBmdW5jdGlvbiBpbml0KCkge1xyXG4gICAgICAgIHNsaWNrU2xpZGVyLnNsaWNrKHtcclxuICAgICAgICAgICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgICAgICAgICAgYXJyb3dzOiB0cnVlLFxyXG4gICAgICAgICAgICBmYWRlOiBmYWxzZSxcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGluaXQ6IGluaXRcclxuICAgIH07XHJcbn0oalF1ZXJ5KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGllbnRTbGlkZXI7Il19
