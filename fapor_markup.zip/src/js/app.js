import clientSlider from './modules/slider-client';
import headerMenu from './modules/header-menu';

(function ($, $wnd, $body, $doc) {

    $(function () {
        clientSlider.init();
        headerMenu.init();
    });

}(jQuery, $(window), $('body'), $(document)));



