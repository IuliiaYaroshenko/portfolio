var clientSlider = (function($) {
    'use strict';

    let slickSlider = $('.slick-slider');

    function init() {
        slickSlider.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: false,
        });
    }

    return {
        init: init
    };
}(jQuery));

export default clientSlider;