
var headerMenu = (function($) {
    'use strict';

    function init() {
        $( ".cross" ).hide();
        $( ".hamburger" ).click(function() {
        $( ".header__nav" ).slideToggle( "slow", function() {
            $( ".hamburger" ).hide();
            $( ".cross" ).show();
        });
        });

        $( ".cross" ).click(function() {
            $( ".header__nav" ).slideToggle( "slow", function() {
                $( ".cross" ).hide();
                $( ".hamburger" ).show();
            });
        });
        }

    return {
        init: init
    };
}(jQuery));

export default headerMenu;