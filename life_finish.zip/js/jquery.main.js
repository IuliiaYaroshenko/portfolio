jQuery(function() {});

$(document).ready(function (){
    $('.button-container').click(function (event){
        $('.button-container,#nav').toggleClass('active')
    });
});