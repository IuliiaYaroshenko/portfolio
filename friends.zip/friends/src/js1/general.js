/* Swiper Slider Settings */

var swiperReachedGoals = new Swiper('.swiper-reached-goals-container', {
    slidesPerView: 4,
    spaceBetween: 20,
    scrollbar: {
        el: '.swiper-scrollbar'
    },

    navigation: {
        nextEl: '.reached-goals-button-next',
        prevEl: '.reached-goals-button-prev'
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        480: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 20
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1280: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1359: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1360: {
            slidesPerView: 4,
            spaceBetween: 20
        }
    }
});


var swiperCurrentGoals = new Swiper('.swiper-current-goals-container', {
    slidesPerView: 4,
    spaceBetween: 20,
    scrollbar: {
        el: '.swiper-scrollbar'
    },

    navigation: {
        nextEl: '.current-goals-button-next',
        prevEl: '.current-goals-button-prev'
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        480: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 20
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1280: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1359: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1380: {
            slidesPerView: 4,
            spaceBetween: 20
        }
    }
});



var swiperOnlineStreams = new Swiper('.swiper-online-streams-container', {
    slidesPerView: 4,
    spaceBetween: 20,
    scrollbar: {
        el: '.swiper-scrollbar'
    },

    navigation: {
        nextEl: '.swiper-online-streams-button-next',
        prevEl: '.swiper-online-streams-button-prev'
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        480: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        640: {
            slidesPerView: 2,
            spaceBetween: 10
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 20
        },
        1024: {
            slidesPerView: 4,
            spaceBetween: 10
        },
        1280: {
            slidesPerView: 4,
            spaceBetween: 20
        }
    }
});


var swiperNews = new Swiper('.swiper-news-container', {
    slidesPerView: 2,
    spaceBetween: 20,
    scrollbar: {
        el: '.swiper-scrollbar'
    },

    navigation: {
        nextEl: '.swiper-news-button-next',
        prevEl: '.swiper-news-button-prev'
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        480: {
            slidesPerView: 1,
            spaceBetween: 10
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 20
        },
        992: {
            slidesPerView: 2,
            spaceBetween: 20
        },
        1280: {
            slidesPerView: 2,
            spaceBetween: 20
        }
    }
});



(function() {
  'use strict';

  function trackScroll() {
    var scrolled = window.pageYOffset;
    var coords = document.documentElement.clientHeight;

    if (scrolled > coords) {
      goTopBtn.classList.add('top-scroll-button-show');
    }
    if (scrolled < coords) {
      goTopBtn.classList.remove('top-scroll-button-show');
    }
  }

  function backToTop() {
    if (window.pageYOffset > 0) {
      window.scrollBy(0, -80);
      setTimeout(backToTop, 15);
    }
  }

  var goTopBtn = document.querySelector('.top-scroll-button');

  window.addEventListener('scroll', trackScroll);
  goTopBtn.addEventListener('click', backToTop);
})();



var searchFocus = document.getElementById("search-input");
var searchShow = document.getElementById('search-btn');
var searchShowMobile = document.getElementById('search-btn-mobile');

searchShow.onclick = function () {
    showBlock('search-full');
    setTimeout(focusOnSearch, 100);
}
searchShowMobile.onclick = function () {
    showBlock('search-full');
    setTimeout(focusOnSearch, 100);
}

var searchHide = document.getElementById('search-full-close-area');
searchHide.onclick = function () {
    hideBlock('search-full');
}

var searchHideTop = document.getElementById('top_close');
searchHideTop.onclick = function () {
    hideBlock('search-full');
}




function showBlock(block) {
    let obj = document.getElementById(block); 
    obj.style.display = "block";
}

function hideBlock(block) {
    let obj = document.getElementById(block); 
    obj.style.display = "none";
}

function focusOnSearch() {
    searchFocus.focus();
}

function showPassword() {
    let pass = document.getElementById('password-input');
    let attr = pass.getAttribute('type');

    if (attr == 'password') pass.setAttribute('type', 'text');
    else pass.setAttribute('type', 'password');
}

function showRepeatPassword() {
    let passRepeat = document.getElementById('password-repeat-input');
    let attrRepeat = passRepeat.getAttribute('type');

    if (attrRepeat == 'password') passRepeat.setAttribute('type', 'text');
    else passRepeat.setAttribute('type', 'password');
}

var emailInput = document.getElementById('email-input');
var passwordInput = document.getElementById('password-input');


var closePreviewIcon = document.getElementById('close-preview-button');
var preview = document.getElementById('attach-image-preview-wrapper');
var previewImage = document.getElementById('attach-image-preview');


var loadFile = function(event) {
    closePreviewIcon.style.display = 'block';
    preview.style.display = 'block';
    var input = event.target;

    var reader = new FileReader();
    reader.onload = function(){
      var dataURL = reader.result;
      var output = previewImage;
      output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
};

var closePreview = function(event) {

    closePreviewIcon.style.display = 'none';
    //preview.style.display = 'none';
    previewImage.src = '';
}





const DesktopMenu = {
    init() {
        document.addEventListener('scroll', desktopMenuHandler)

        function desktopMenuHandler(event) {
            let desktopMenuElement = document.querySelector('.top-nav');
            if (window.pageYOffset >= 200) {
                if (!desktopMenuElement.classList.contains('fixed')) {
                    desktopMenuElement.classList.add('fixed');
                }
            } else {
                if (desktopMenuElement.classList.contains('fixed')) {
                    desktopMenuElement.classList.remove('fixed');
                }
            }
        }
    },

};








$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
});

$(document).ready(function(){
    $('.btn_search ').click(function() {
        $('.holder_box_user').toggleClass('active');
        $(this).toggleClass('open');

    });


    $('.btn_search').click(function() {
        if ($(".holder_box_user").hasClass("active")) {
            $(this).html('Расширенный поиск');
        } else {

            $(this).html('Расширенный поиск');
        };



    });
});



