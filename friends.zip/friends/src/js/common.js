$(function() {
$('.btn_full_btn').click(function() {
    $('.mission_block p').toggleClass('active');
    $(this).toggleClass('open');
    
})


$('.btn_full_btn').click(function() {
          if ($(".mission_block p").hasClass("active")) {
$(this).html('Скрыть полное описание');
      } else {

    $(this).html('Рассыкрыть полное описание');
      };


    
})
}); 


$(function() {
$('.btn_lenta_more').click(function() {
    $('.lenta_sec .block').toggleClass('active');

    
})
$('.btn_lenta_more').click(function() {
          if ($(".lenta_sec .block").hasClass("active")) {
$(this).html('Скрыть')
      } else {

    $(this).html('Показать еще')
      };


    
})

}); 

$(function() {
$('.btn_event_line').click(function() {
    $('.event_line_comments').toggleClass('active');




    
})
 $('.btn_event_line').click(function() {
          if ($(".event_line_comments").hasClass("active")) {
$(this).html('Скрыть')
      } else {

    $(this).html('Показать еще')
      };   
})

});

$(function() {
    $('.btn_message_line').click(function() {
        $('.message_list_comments').toggleClass('active');





    })
    $('.btn_message_line').click(function() {
        if ($(".message_list_comments").hasClass("active")) {
            $(this).html('Скрыть')
        } else {

            $(this).html('Показать еще')
        };
    })

});

$(function() {
$(".js-q-fancybox").fancybox({
  protect: true,
  buttons : [
    'zoom',
    'thumbs',
    'close'
  ]
})
});
  $(function() {
  var austDay = new Date();
  austDay = new Date(austDay.getFullYear() + 1, 1 - 1, 26);
  $('#defaultCountdown').countdown({until: austDay});
  $('#year').text(austDay.getFullYear());
$('#noSeconds').countdown({until: austDay, format: 'dHM'})
  });
	$(function() {

  $(".toggle_mnu").click(function() {
      $(".sandwich").toggleClass("active");
  });



  $(".toggle_mnu").click(function() {
      if ($(".top_mnu").is(":visible")) {
          $(".top_text").css("opacity", "1");
          $(".top_mnu").fadeOut(600);
          $(".top_mnu ul li a").removeClass("fadeInUp animated");
      } else {
          $(".top_text").css("opacity", ".1");
          $(".top_mnu").fadeIn(600);
          $(".top_mnu ul li a").addClass("fadeInUp animated");
      };
  });

});

    $(function() {
$('.close').click(function() {
  $('.sucsess_wrap').hide();
})
        });


  $(".scroll_down").click(function() {
    $("html, body").animate({ scrollTop: $(".main_head").height()+30 }, "slow");
    return false;
  }); 