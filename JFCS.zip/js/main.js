(function($) {
	$(document).ready(function() {
		$("select").fancySelect();
		$('input[placeholder], textarea[placeholder]').placeholder();

		$('.slider').bxSlider({
		 	mode:'fade',
		  	speed:1000,
		  	pager:false,
		  	auto:true
		});

		$( "#nav li" ).each(function(){
		     if($(this).find('ul').length){
		          $(this).find('>a').append('<span class="drops"></span>');
		     }
		});

	    jQuery(document).on('click', ".menu_trigger", function (e) {
	        e.preventDefault()
	        window.setTimeout(function() {
	            if(jQuery('#nav').hasClass('clicked')){
	                jQuery('#nav').stop(true,true).animate({height:'hide'},100);
	                jQuery('#nav').removeClass('clicked');
	            }else{
	                jQuery('#nav').stop(true,true).animate({height:'show'},400);
	                jQuery('#nav').addClass('clicked');
	            }
	        }, 400);
	        return false;
	    });
	    jQuery("#nav").on('click', '.drops', function () {
	        if (jQuery(this).hasClass("actives")) {
	            jQuery(this).removeClass("actives").parent().next().slideUp();
	        } else {
	            jQuery(this).addClass("actives").parent().next().slideDown();
	        }
	        return false;
	    });
	     jQuery(".parent-menu").on('click', '.drops_sidebar', function () {
	        if (jQuery(this).hasClass("actives")) {
	            jQuery(this).removeClass("actives").parent().next().slideUp();
	        } else {
	            jQuery(this).addClass("actives").parent().next().slideDown();
	        }
	        return false;
	    });
	});
	$(window).resize(function() {
	    if($(document).width() > 768){
	      $( "#nav" ).addClass("active");
	      $( "#nav .drop" ).attr('style','');
	      $( "#nav" ).attr('style','');
	      $( "#nav" ).removeClass("clicked");
	      $( "#nav .active" ).removeClass('active');
	    }
	    else {
	        $( "#nav" ).removeClass("active");
	    }
	});
	$(window).resize(function() {
	    if($(document).width() > 768){
	      $( ".parent-menu" ).addClass("active");
	      $( ".parent-menu .drop" ).attr('style','');
	      $( ".parent-menu" ).attr('style','');
	      $( ".parent-menu" ).removeClass("clicked");
	      $( ".parent-menu .active" ).removeClass('active');
	    }
	    else {
	        $( ".parent-menu" ).removeClass("active");
	    }
	});
	var pageNum, max, nextLink;
	var loading = false;
	
	


	function equalHeight(group) {
	    var tallest = 0;
	    group.each(function() {
	        var thisHeight = $(this).attr("style", "").height();
	        if(thisHeight > tallest) {
	            tallest = thisHeight;
	        }
	    });
	    group.height(tallest);
	}

})(jQuery);