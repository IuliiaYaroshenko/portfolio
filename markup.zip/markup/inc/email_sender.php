<?php
  if (isset($_POST['action']) && $_POST['action'] == 'am_send_email' && $_POST['fields']){
    $toReturn = array();
    $message = '';
    $fields = json_decode($_POST['fields']);
    if(is_array($fields)){
      foreach ($fields as $field){
        if (!empty($field[1])){
          $message .= $field[0].' '.(is_array($field[1])? implode($field[1], ', ') : $field[1]).'<br>';
        }
      }
    }
    if ($message){
      $message .= 'URL: '.$_POST['url'].'<br>';
      // $message .= 'IP: '.getRealIp().'<br>';

      $to = 'lbetts@gcmogam.com';

      $subject = 'Newsletter subscription';

      $headers = "From: " . strip_tags($_POST['email']) . "\r\n";
      $headers .= "Reply-To: ". strip_tags($_POST['email']) . "\r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

      if (mail($to, $subject, $message, $headers)) {
        $toReturn['response'] = 'ok';
      } else {
        $toReturn['response'] = 'error';
      }

    }else{
      $toReturn['response'] = 'error';
    }
    echo json_encode($toReturn);
    die();
  }
  else{
    die();
  }

  function getRealIp() {
       if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
         $ip=$_SERVER['HTTP_CLIENT_IP'];
       } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  //to check ip is pass from proxy
         $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
       } else {
         $ip=$_SERVER['REMOTE_ADDR'];
       }
       return $ip;
    }
?>
